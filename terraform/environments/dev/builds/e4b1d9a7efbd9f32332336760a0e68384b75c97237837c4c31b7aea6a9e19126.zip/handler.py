import json
import logging
import os

import boto3
from botocore.exceptions import BotoCoreError, ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def process_order(record, table, sns, topic_arn):
    """Save an order and publish its event, supporting retries."""

    order = json.loads(record["body"])

    order_id = order["order_id"]
    customer_id = order["customer_id"]
    items = order["items"]

    if not isinstance(order_id, str) or not order_id.strip():
        raise ValueError("Invalid order_id")

    if not isinstance(customer_id, str) or not customer_id.strip():
        raise ValueError("Invalid customer_id")

    if not isinstance(items, list) or not items:
        raise ValueError("Invalid items")

    try:
        table.put_item(
            Item={
                "order_id": order_id,
                "customer_id": customer_id,
                "items": items,
                "status": "created",
                "event_status": "pending",
            },
            ConditionExpression="attribute_not_exists(order_id)",
        )

    except ClientError as error:
        error_code = error.response["Error"]["Code"]

        if error_code != "ConditionalCheckFailedException":
            raise

        existing_order = table.get_item(
            Key={"order_id": order_id},
            ConsistentRead=True,
        ).get("Item")

        if existing_order is None:
            raise RuntimeError("Existing order could not be retrieved") from error

        if existing_order.get("event_status") == "published":
            logger.info("Order already processed: %s", order_id)
            return

        if existing_order.get("event_status") != "pending":
            raise ValueError("Unexpected event_status") from error

        logger.info("Retrying pending event for order: %s", order_id)

    event = {
        "event_type": "OrderCreated",
        "order_id": order_id,
        "customer_id": customer_id,
        "items": items,
    }

    sns.publish(
        TopicArn=topic_arn,
        Message=json.dumps(event),
    )

    table.update_item(
        Key={"order_id": order_id},
        UpdateExpression="SET event_status = :published",
        ConditionExpression="event_status = :pending",
        ExpressionAttributeValues={
            ":published": "published",
            ":pending": "pending",
        },
    )

    logger.info("Order processed: %s", order_id)


def lambda_handler(event, context):
    """Process SQS records and report individual failures."""
    del context

    table_name = os.environ["ORDERS_TABLE_NAME"]
    topic_arn = os.environ["ORDER_EVENTS_TOPIC_ARN"]

    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table(table_name)
    sns = boto3.client("sns")

    failures = []

    for record in event["Records"]:
        try:
            process_order(record, table, sns, topic_arn)

        except (
            BotoCoreError,
            ClientError,
            KeyError,
            TypeError,
            ValueError,
            RuntimeError,
        ):
            message_id = record["messageId"]

            logger.exception(
                "Failed to process SQS message: %s",
                message_id,
            )

            failures.append({"itemIdentifier": message_id})

    return {"batchItemFailures": failures}
